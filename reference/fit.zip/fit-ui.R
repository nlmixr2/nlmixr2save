ui <- function () 
{
    ini({
        tka <- 0.460602230258314
        tcl <- c(-Inf, 1.01201940639598, 4.60517018598809)
        tv <- 3.45860562389771
        add.sd <- c(0, 0.691607398976993)
        eta.ka ~ 0.401996787948019
        eta.cl ~ 0.0689555151948068
        eta.v ~ 0.0199057220552622
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        linCmt() ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "one.cmt", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

